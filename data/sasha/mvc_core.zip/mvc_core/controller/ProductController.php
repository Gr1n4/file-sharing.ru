<?php 


class ProductController {
	


	public function actionList() {
		echo "hello product";
		return true;
	}
}