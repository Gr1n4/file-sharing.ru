<?php 

return array(
	'host' => 'localhost',
	'dbname' => 'mvc_core',
	'user' => 'root',
	'password' => '19580211',
);