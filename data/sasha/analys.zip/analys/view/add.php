<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Add</title>
	<link rel="stylesheet" href="/template/style.css">
</head>
<body>
	<form action="add/index" method="post">
		Фамилия: <input type="text" name="surname">
		Выручка: <input type="text" name="revenue">
		Кредиты и займы: <input type="text" name="loan">
		Кредиторская задолженность: <input type="text" name="debt">
		Задолженность перед учередителями по выплате доходов: <input type="text" name="founder">
		Прочие краткосрочные обязательства: <input type="text" name="obligation">
		Дата: <input type="date" name="date">
		<input type="submit">
	</form>
</body>
</html>