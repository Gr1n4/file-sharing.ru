<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>General Analys</title>
	<link rel="stylesheet" href="template/style.css">
</head>
<body>
	<a href="/add">Add</a>
	<a href="/edit">Edit</a>
	<a href="/analys">Analys</a>
</body>
</html>