<?php

return array(
	'host' => 'localhost',
	'dbname' => 'analys',
	'user' => 'root',
	'password' => '1'
);