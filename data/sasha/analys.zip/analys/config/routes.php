<?php 

return array(
	'' => 'show/index',
	'add' => 'add/add',
	'add/index' => 'add/index',
	'analys' => 'analys',
	'edit' => 'edit'
);