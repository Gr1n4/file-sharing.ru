<?php

class Show_controller {
	
	public static function action_index() {
		require_once(ROOT . '/view/index.php');
	}
}