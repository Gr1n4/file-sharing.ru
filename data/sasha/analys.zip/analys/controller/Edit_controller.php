<?php 

class Edit_controller {
	
	public function edit() {
		echo "edit";
	}
}