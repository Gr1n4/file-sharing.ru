<?php 

class Analys_controller {
	
	public function analys() {
		echo "analys";
	}
}